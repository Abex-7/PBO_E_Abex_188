package Perpustakaan;

public interface Peminjaman {

    void pinjamBuku(String judul);

    void kembalikanBuku(String judul);

}